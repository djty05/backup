import { useState, useEffect } from "react";
import { extractReportData, createReport, updateReport, getReport } from "../api/backendFunctions";
import { base44 } from "../api/base44Client";

const C = {
  bg: "#faf5ee",
  text: "#3b1320",
  muted: "#8a6070",
  border: "#e8ddd0",
  accent: "#8883d1",
  card: "#fff",
};

const PLATFORMS = ["Instagram", "TikTok", "YouTube", "Facebook", "Snapchat"];
const PLACEMENT_TYPES = ["Feed Post", "Reel", "Story", "TikTok Video", "YouTube Integration", "YouTube Dedicated", "YouTube Short", "Snap"];

const emptyDeliverable = () => ({
  id: Date.now(),
  platforms: [],
  placement_types: [],
  post_url: "",
  driveFolderLinks: [""],
});

export default function SubmitReport() {
  const reportIdFromUrl = new URLSearchParams(window.location.search).get("reportId");
  const [existingReport, setExistingReport] = useState(null);
  const [loadingReport, setLoadingReport] = useState(!!reportIdFromUrl);

  const [campaign, setCampaign] = useState({
    campaign_title: "", campaign_name: "", brand_name: "", creator_name: "",
    xero_quote_ref: "", bonus_posts_noted: "", google_drive_folder: "",
  });

  const parseCampaignTitle = (title) => {
    const xParts = title.split(/\s+[xX]\s+/);
    const creator_name = xParts[0]?.trim() || "";
    const rest = xParts[1] || "";
    const pipeParts = rest.split("|");
    const brand_name = pipeParts[0]?.trim() || "";
    return { campaign_name: title.trim(), creator_name, brand_name };
  };

  useEffect(() => {
    if (reportIdFromUrl) {
      getReport({ id: reportIdFromUrl }).then(res => {
        const report = res.report;
        setExistingReport(report);
        setCampaign({
          campaign_title: report.campaign_name,
          campaign_name: report.campaign_name,
          brand_name: report.brand_name,
          creator_name: report.creator_name,
          xero_quote_ref: report.xero_quote_ref || "",
          bonus_posts_noted: report.bonus_posts_noted || "",
          google_drive_folder: report.google_drive_link || "",
        });
        
        // Load existing deliverables from asset_metrics if available
        if (report.asset_metrics && report.asset_metrics.length > 0) {
          const loadedDeliverables = report.asset_metrics.map((asset, idx) => ({
            id: idx,
            platforms: report.platforms || [],
            placement_types: [asset.type] || [],
            post_url: report.content_link || "",
            driveFolderLinks: [report.google_drive_link || ""],
          }));
          setDeliverables(loadedDeliverables);
        }
        
        setGlobalStep("campaign");
        setLoadingReport(false);
      }).catch(err => {
        setError("Failed to load report: " + err.message);
        setLoadingReport(false);
      });
    }
  }, [reportIdFromUrl]);

  const [deliverables, setDeliverables] = useState([emptyDeliverable()]);
  const [currentDeliverable, setCurrentDeliverable] = useState(0);
  const [globalStep, setGlobalStep] = useState("campaign");
  const [deliverableStep, setDeliverableStep] = useState("details");
  const [error, setError] = useState(null);
  const [reportSlug, setReportSlug] = useState(null);
  const [extractionNotes, setExtractionNotes] = useState("");

  const d = deliverables[currentDeliverable];

  const updateDeliverable = (patch) => {
    setDeliverables(prev => prev.map((item, i) => i === currentDeliverable ? { ...item, ...patch } : item));
  };

  const toggleChip = (field, value) => {
    updateDeliverable({ [field]: d[field].includes(value) ? d[field].filter(v => v !== value) : [...d[field], value] });
  };

  const handleAddDeliverable = () => {
    setDeliverables(prev => [...prev, emptyDeliverable()]);
    setCurrentDeliverable(deliverables.length);
    setDeliverableStep("details");
    setError(null);
  };

  const handleFinalSubmit = async () => {
    setGlobalStep("processing");
    setError(null);

    try {
      const allPlatforms = [...new Set(deliverables.flatMap(d => d.platforms))];
      const allPlacements = [...new Set(deliverables.flatMap(d => d.placement_types))];

      const campaignData = {
        campaign_name: campaign.campaign_name,
        brand_name: campaign.brand_name,
        creator_name: campaign.creator_name,
        xero_quote_ref: campaign.xero_quote_ref,
        bonus_posts_noted: campaign.bonus_posts_noted,
        platforms: allPlatforms,
        platform: allPlatforms[0] || "",
        placement_types: allPlacements,
        placement_type: allPlacements[0] || "",
        google_drive_link: campaign.google_drive_folder || "",
        content_link: deliverables[0]?.post_url || "",
      };

      let reportId;

      if (existingReport) {
        // Update existing report
        await updateReport({ reportId: existingReport.id, data: campaignData });
        reportId = existingReport.id;
        setReportSlug(existingReport.report_slug);
      } else {
        // Create new report
        const slug = `${campaign.campaign_name}-${campaign.creator_name}-${Date.now()}`
          .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
        
        const createRes = await createReport({
          campaignData: { ...campaignData, status: campaign.google_drive_folder ? "Processing" : "Needs Review" },
          slug,
        });
        reportId = createRes.reportId;
        setReportSlug(slug);
      }

      // Fire extraction in background
      if (campaign.google_drive_folder) {
        extractReportData({
          reportId,
          driveFolderLink: campaign.google_drive_folder,
          deliverables: deliverables.map((d) => ({
            platforms: d.platforms,
            placement_types: d.placement_types,
            driveFolderLinks: d.driveFolderLinks || [d.driveFolderLink],
            post_url: d.post_url,
          })),
          postUrl: deliverables[0]?.post_url || "",
          platforms: allPlatforms,
        }).catch(() => {});
      }

      setGlobalStep("done");
    } catch (err) {
      console.error(err);
      setError(err?.message || err?.response?.data?.message || "Something went wrong. Please try again.");
      setGlobalStep("review");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div style={{ background: C.text, padding: "16px 32px", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#faf5ee", letterSpacing: -0.5, fontFamily: "'Playfair Display', serif" }}>Good Answer</div>
        <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.2)", margin: "0 4px" }} />
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: 1, textTransform: "uppercase" }}>Campaign Report Submission</div>
        {globalStep === "deliverable" && (
          <div style={{ marginLeft: "auto", fontSize: 12, color: "#444" }}>
            Deliverable {currentDeliverable + 1} of {deliverables.length}
          </div>
        )}
      </div>

      <div style={{ maxWidth: 580, margin: "0 auto", padding: "44px 24px" }}>

        {loadingReport && (
          <div style={{ textAlign: "center", padding: "72px 0" }}>
            <div style={{ width: 48, height: 48, margin: "0 auto 28px", border: `3px solid ${C.border}`, borderTop: `3px solid ${C.text}`, borderRadius: "50%", animation: "spin 0.9s linear infinite" }} />
            <p style={{ color: C.muted }}>Loading report...</p>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        )}

        {!loadingReport && (
          <>
        {/* STEP: CAMPAIGN */}
        {globalStep === "campaign" && (
          <form onSubmit={(e) => {
            e.preventDefault();
            if (!campaign.campaign_title || !campaign.brand_name || !campaign.creator_name) {
              setError("Please enter a campaign name in the correct format.");
              return;
            }
            setError(null);
            setGlobalStep("deliverable");
          }}>
            <h1 style={h1}>Campaign Details</h1>
            <p style={sub}>Start with the basics — you'll add each deliverable next.</p>
            {error && <Err>{error}</Err>}
            <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
              <div>
                <label style={labelStyle}>Campaign Name *</label>
                <input
                  value={campaign.campaign_title}
                  onChange={e => {
                    const parsed = parseCampaignTitle(e.target.value);
                    setCampaign(p => ({ ...p, campaign_title: e.target.value, ...parsed }));
                  }}
                  placeholder="e.g. Jessica Smith X Bondi Sands | Summer 2026"
                  style={inputStyle}
                />
                <div style={{ fontSize: 11, color: "#444", marginTop: 4 }}>Format: Talent Name X Brand Name | Campaign or Timing Detail</div>
                {campaign.creator_name && campaign.brand_name && (
                  <div style={{ fontSize: 12, color: "#555", marginTop: 6, display: "flex", gap: 12 }}>
                    <span>👤 {campaign.creator_name}</span>
                    <span>🏷️ {campaign.brand_name}</span>
                  </div>
                )}
              </div>
              <Field label="Xero Quote / Invoice Ref" value={campaign.xero_quote_ref}
                onChange={v => setCampaign(p => ({ ...p, xero_quote_ref: v }))}
                placeholder="e.g. INV-0042" hint="Used to cross-check deliverables before report is approved" />
              <div>
                <label style={labelStyle}>Bonus Posts / Team Notes</label>
                <textarea value={campaign.bonus_posts_noted}
                  onChange={e => setCampaign(p => ({ ...p, bonus_posts_noted: e.target.value }))}
                  placeholder="e.g. Creator added an extra story not in original quote..."
                  rows={2} style={{ ...inputStyle, resize: "vertical", fontFamily: "inherit" }} />
              </div>
              <Field label="Campaign Folder (Google Drive)" value={campaign.google_drive_folder}
                onChange={v => setCampaign(p => ({ ...p, google_drive_folder: v }))}
                placeholder="https://drive.google.com/drive/folders/..." hint="Top-level folder containing all supporting data (screenshots, Foam reports, etc)" />
            </div>
            <button type="submit" style={primaryBtn}>Add Deliverables →</button>
          </form>
        )}

        {/* STEP: DELIVERABLE */}
        {globalStep === "deliverable" && (
          <div>
            {deliverables.length > 1 && (
              <div style={{ display: "flex", gap: 6, marginBottom: 28, flexWrap: "wrap" }}>
                {deliverables.map((_, i) => (
                  <button key={i} onClick={() => { setCurrentDeliverable(i); setDeliverableStep("details"); }}
                    style={{ background: i === currentDeliverable ? "#1e1b4b" : "#141414", border: `1px solid ${i === currentDeliverable ? "#6366f1" : "#222"}`, borderRadius: 20, padding: "5px 14px", color: i === currentDeliverable ? "#a5b4fc" : "#555", fontSize: 12, cursor: "pointer" }}>
                    Deliverable {i + 1}
                  </button>
                ))}
              </div>
            )}

            {deliverableStep === "details" && (
              <form onSubmit={(e) => {
                e.preventDefault();
                if (d.platforms.length === 0) { setError("Select at least one platform."); return; }
                setError(null);
                setDeliverableStep("drive");
              }}>
                <h1 style={h1}>Deliverable {currentDeliverable + 1}</h1>
                <p style={sub}>What did the creator post?</p>
                {error && <Err>{error}</Err>}
                <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                  <div>
                    <label style={labelStyle}>Platform(s) * <Muted>select all that apply</Muted></label>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                      {PLATFORMS.map(p => <Chip key={p} label={p} selected={d.platforms.includes(p)} onClick={() => toggleChip("platforms", p)} />)}
                    </div>
                  </div>
                  <div>
                    <label style={labelStyle}>Placement Type(s) <Muted>select all that apply</Muted></label>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                      {PLACEMENT_TYPES.map(p => <Chip key={p} label={p} selected={d.placement_types.includes(p)} onClick={() => toggleChip("placement_types", p)} />)}
                    </div>
                  </div>
                  <Field label="Post URL" value={d.post_url} onChange={v => updateDeliverable({ post_url: v })}
                    placeholder="https://www.instagram.com/p/..." hint="Leave blank for Stories or expired content" />
                </div>
                <button type="submit" style={primaryBtn}>Add Drive Folder →</button>
              </form>
            )}

            {deliverableStep === "drive" && (
              <div>
                <h1 style={h1}>Google Drive Folder(s)</h1>
                <p style={sub}>Paste the Drive folder link(s) containing the screenshots for this {[...d.platforms, ...d.placement_types].join(" / ") || "deliverable"}. Add multiple folders if needed — the AI will read all of them.</p>
                {error && <Err>{error}</Err>}
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {(d.driveFolderLinks || [""]).map((link, idx) => (
                    <div key={idx} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <div style={{ flex: 1 }}>
                        {(d.driveFolderLinks || []).length > 1 && (
                          <div style={{ fontSize: 11, color: "#444", marginBottom: 4 }}>Folder {idx + 1}</div>
                        )}
                        <input
                          value={link}
                          onChange={e => {
                            const updated = [...(d.driveFolderLinks || [""])];
                            updated[idx] = e.target.value;
                            updateDeliverable({ driveFolderLinks: updated });
                          }}
                          placeholder="https://drive.google.com/drive/folders/..."
                          style={inputStyle}
                        />
                      </div>
                      {(d.driveFolderLinks || [""]).length > 1 && (
                        <button type="button" onClick={() => {
                          const updated = (d.driveFolderLinks || [""]).filter((_, i) => i !== idx);
                          updateDeliverable({ driveFolderLinks: updated });
                        }} style={{ background: "none", border: "1px solid #333", borderRadius: 6, color: "#555", cursor: "pointer", padding: "8px 10px", fontSize: 13, flexShrink: 0 }}>✕</button>
                      )}
                    </div>
                  ))}
                </div>
                <button type="button" onClick={() => updateDeliverable({ driveFolderLinks: [...(d.driveFolderLinks || [""]), ""] })}
                  style={{ marginTop: 10, background: "none", border: `1px dashed ${C.border}`, borderRadius: 8, color: C.muted, cursor: "pointer", padding: "10px 16px", fontSize: 13, width: "100%", fontFamily: "'DM Sans', sans-serif" }}>
                  ＋ Add another Drive folder
                </button>
                {(d.driveFolderLinks || []).some(Boolean) && (
                  <div style={{ marginTop: 12, padding: "10px 14px", background: "#f0f8f0", border: "1px solid #b8ddb8", borderRadius: 8, fontSize: 13, color: "#3a8a4a" }}>
                    ✓ {(d.driveFolderLinks || []).filter(Boolean).length} Drive folder{(d.driveFolderLinks || []).filter(Boolean).length > 1 ? "s" : ""} linked — AI will read images from {(d.driveFolderLinks || []).filter(Boolean).length > 1 ? "all folders" : "this folder"}
                  </div>
                )}
                <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
                  <button onClick={() => setDeliverableStep("details")} style={secondaryBtn}>← Back</button>
                  <button onClick={() => setDeliverableStep("confirm")} style={{ ...primaryBtn, marginTop: 0, flex: 2 }}>
                    Done with this deliverable →
                  </button>
                </div>
              </div>
            )}

            {deliverableStep === "confirm" && (
              <div>
                <h1 style={h1}>Deliverable {currentDeliverable + 1} saved ✓</h1>
                <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 20, marginBottom: 28 }}>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12 }}>
                    {[...d.platforms, ...d.placement_types].map(t => <Tag key={t}>{t}</Tag>)}
                  </div>
                  {d.post_url && <div style={{ fontSize: 13, color: C.muted, marginBottom: 6 }}>🔗 {d.post_url}</div>}
                  {(d.driveFolderLinks || []).filter(Boolean).length > 0
                    ? <div style={{ fontSize: 13, color: "#3a8a4a" }}>✓ {(d.driveFolderLinks || []).filter(Boolean).length} Drive folder{(d.driveFolderLinks || []).filter(Boolean).length > 1 ? "s" : ""} linked</div>
                    : <div style={{ fontSize: 13, color: C.muted }}>No Drive folder added</div>
                  }
                </div>
                <p style={{ ...sub, marginBottom: 24 }}>What would you like to do next?</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  <button onClick={handleAddDeliverable}
                    style={{ background: C.card, border: `1.5px solid ${C.accent}`, borderRadius: 8, padding: "14px", color: C.accent, fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>
                    ＋ Add another deliverable
                  </button>
                  <button onClick={() => setGlobalStep("review")} style={{ ...primaryBtn, marginTop: 0 }}>
                    All deliverables added — Review & Submit →
                  </button>
                  <button onClick={() => setDeliverableStep("drive")}
                    style={{ background: "none", border: "none", color: "#444", cursor: "pointer", fontSize: 13, paddingTop: 4 }}>
                    ← Edit Drive folders
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP: REVIEW */}
        {globalStep === "review" && (
          <div>
            <h1 style={h1}>Review & Submit</h1>
            <p style={sub}>Check everything looks right before generating the report.</p>
            {error && <Err>{error}</Err>}
            <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 20, marginBottom: 20 }}>
              <div style={{ fontSize: 12, color: C.muted, marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Campaign</div>
              <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 4, fontFamily: "'Playfair Display', serif" }}>{campaign.campaign_name}</div>
              <div style={{ fontSize: 14, color: C.muted }}>{campaign.brand_name} · {campaign.creator_name}</div>
              {campaign.xero_quote_ref && <div style={{ fontSize: 13, color: C.muted, marginTop: 6 }}>Xero: {campaign.xero_quote_ref}</div>}
              {campaign.bonus_posts_noted && <div style={{ fontSize: 13, color: "#dd7d4f", marginTop: 6 }}>⚠️ {campaign.bonus_posts_noted}</div>}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 28 }}>
              {deliverables.map((del, i) => (
                <div key={del.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Deliverable {i + 1}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                      {[...del.platforms, ...del.placement_types].map(t => <Tag key={t}>{t}</Tag>)}
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: C.muted, textAlign: "right" }}>
                    {(del.driveFolderLinks || []).filter(Boolean).length > 0
                      ? <div style={{ color: "#3a8a4a" }}>✓ {(del.driveFolderLinks || []).filter(Boolean).length} Drive folder{(del.driveFolderLinks || []).filter(Boolean).length > 1 ? "s" : ""}</div>
                      : <div>No Drive folder</div>}
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => { setGlobalStep("deliverable"); setDeliverableStep("confirm"); }} style={secondaryBtn}>← Edit</button>
              <button onClick={handleFinalSubmit} style={{ ...primaryBtn, marginTop: 0, flex: 2 }}>Generate Report →</button>
            </div>
          </div>
        )}

        {/* STEP: PROCESSING */}
        {globalStep === "processing" && (
          <div style={{ textAlign: "center", padding: "72px 0" }}>
            <div style={{ width: 48, height: 48, margin: "0 auto 28px", border: `3px solid ${C.border}`, borderTop: `3px solid ${C.text}`, borderRadius: "50%", animation: "spin 0.9s linear infinite" }} />
            <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 10, fontFamily: "'Playfair Display', serif", color: C.text }}>Building your report...</h2>
            <p style={{ color: C.muted, fontSize: 14, maxWidth: 320, margin: "0 auto" }}>AI is reading the Drive folder, extracting metrics, and generating the analysis.</p>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        )}

        {/* STEP: DONE */}
        {globalStep === "done" && (
          <div style={{ textAlign: "center", padding: "60px 0" }}>
            <div style={{ fontSize: 52, marginBottom: 20 }}>✅</div>
            <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 10, fontFamily: "'Playfair Display', serif", color: C.text }}>Report created!</h2>
            <p style={{ color: C.muted, fontSize: 14, marginBottom: 6 }}>
              Status is <strong style={{ color: "#dd7d4f" }}>Needs Review</strong> — verify deliverables against Xero before sending to client.
            </p>
            {extractionNotes && (
              <div style={{ background: "#fff8ee", border: "1px solid #f0ddb0", borderRadius: 10, padding: "12px 16px", margin: "16px auto", maxWidth: 400, textAlign: "left", fontSize: 13, color: C.muted }}>
                <strong style={{ color: "#dd7d4f" }}>AI Notes:</strong> {extractionNotes}
              </div>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: 12, alignItems: "center", marginTop: 28 }}>
              <a href={`/Report?slug=${reportSlug}`} target="_blank"
                style={{ ...primaryBtn, marginTop: 0, display: "inline-block", textDecoration: "none" }}>
                View Report →
              </a>
              <button onClick={() => window.location.reload()} style={{ background: "none", border: "none", color: C.accent, cursor: "pointer", fontSize: 14, fontFamily: "'DM Sans', sans-serif" }}>
                Submit another report
              </button>
            </div>
          </div>
        )}

        </>
        )}

      </div>
    </div>
  );
}

const h1 = { fontSize: 26, fontWeight: 700, marginBottom: 6, marginTop: 0, fontFamily: "'Playfair Display', serif", color: C.text };
const sub = { color: C.muted, fontSize: 14, marginBottom: 28, marginTop: 0, fontFamily: "'DM Sans', sans-serif" };
const labelStyle = { display: "block", fontSize: 13, color: C.muted, marginBottom: 8, fontWeight: 500, fontFamily: "'DM Sans', sans-serif" };
const inputStyle = { width: "100%", background: C.card, border: `1px solid ${C.border}`, borderRadius: 8, padding: "11px 14px", color: C.text, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "'DM Sans', sans-serif" };
const primaryBtn = { marginTop: 24, width: "100%", background: C.text, border: "none", borderRadius: 8, padding: "14px", color: "#faf5ee", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" };
const secondaryBtn = { marginTop: 24, background: "transparent", border: `1px solid ${C.border}`, borderRadius: 8, padding: "14px 20px", color: C.muted, fontWeight: 500, fontSize: 15, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" };

function Field({ label, value, onChange, placeholder, hint }) {
  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={inputStyle} />
      {hint && <div style={{ fontSize: 11, color: C.muted, marginTop: 4, fontFamily: "'DM Sans', sans-serif" }}>{hint}</div>}
    </div>
  );
}

function Chip({ label, selected, onClick }) {
  return (
    <button type="button" onClick={onClick}
      style={{ background: selected ? "#ede9f8" : C.card, border: `1.5px solid ${selected ? C.accent : C.border}`, borderRadius: 6, padding: "7px 14px", color: selected ? C.accent : C.muted, fontSize: 13, cursor: "pointer", fontWeight: selected ? 600 : 400, fontFamily: "'DM Sans', sans-serif" }}>
      {label}
    </button>
  );
}

function Tag({ children }) {
  return (
    <span style={{ background: "#ede9f8", border: `1px solid #d0cdf0`, color: C.accent, borderRadius: 4, padding: "3px 10px", fontSize: 11, fontFamily: "'DM Sans', sans-serif" }}>{children}</span>
  );
}

function Err({ children }) {
  return <div style={{ background: "#fdf0f0", border: "1px solid #f5c0c0", borderRadius: 8, padding: "11px 14px", marginBottom: 18, color: "#b03030", fontSize: 14, fontFamily: "'DM Sans', sans-serif" }}>{children}</div>;
}

function Muted({ children }) {
  return <span style={{ color: C.muted, fontWeight: 400, fontSize: 12 }}> — {children}</span>;
}