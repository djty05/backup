import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { listReports, updateReportStatus, deleteReport, updateReport } from "../api/backendFunctions";

const C = {
  bg: "#faf5ee",
  text: "#3b1320",
  muted: "#8a6070",
  border: "#e8ddd0",
  accent: "#8883d1",
  card: "#fff",
};

const statusColors = {
  "Processing": "#dd7d4f",
  "Needs Review": "#dd7d4f",
  "Approved": "#3a8a4a",
  "Sent": "#3a8a4a",
};

export default function Dashboard() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [brandFilter, setBrandFilter] = useState("all");
  const [talentFilter, setTalentFilter] = useState("all");
  const [performanceSort, setPerformanceSort] = useState("none");
  const [searchQuery, setSearchQuery] = useState("");
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await listReports({});
        setReports(res.reports || []);
      } catch (err) {
        console.error("Failed to fetch reports:", err);
      }
      setLoading(false);
    };
    fetchReports();
    
    // Refresh every 5 seconds
    const interval = setInterval(fetchReports, 5000);
    return () => clearInterval(interval);
  }, []);

  const updateStatus = async (reportId, newStatus) => {
    try {
      await updateReportStatus({ reportId, status: newStatus });
      setReports(prev => prev.map(r => r.id === reportId ? { ...r, status: newStatus } : r));
    } catch (err) {
      console.error("Failed to update status:", err);
    }
  };

  const getShareLink = (slug) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/Report?slug=${slug}`;
  };

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = async (reportId) => {
    if (!window.confirm("Are you sure? This cannot be undone.")) return;
    try {
      await deleteReport({ reportId });
      setReports(prev => prev.filter(r => r.id !== reportId));
    } catch (err) {
      console.error("Failed to delete report:", err);
    }
  };



  const getPerformanceScore = (report) => {
    return (report.total_views || 0) + (report.engagement_rate || 0) * 100 + (report.likes || 0);
  };

  let filteredReports = reports.filter(r => {
    const matchStatus = statusFilter === "all" || r.status === statusFilter;
    const matchBrand = brandFilter === "all" || r.brand_name === brandFilter;
    const matchTalent = talentFilter === "all" || r.creator_name === talentFilter;
    const matchSearch = searchQuery === "" || 
      r.campaign_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.brand_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.creator_name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchStatus && matchBrand && matchTalent && matchSearch;
  });

  if (performanceSort === "best") {
    filteredReports.sort((a, b) => getPerformanceScore(b) - getPerformanceScore(a));
  } else if (performanceSort === "worst") {
    filteredReports.sort((a, b) => getPerformanceScore(a) - getPerformanceScore(b));
  }

  const uniqueBrands = [...new Set(reports.map(r => r.brand_name))].sort();
  const uniqueTalents = [...new Set(reports.map(r => r.creator_name))].sort();

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 48, height: 48, margin: "0 auto 20px", border: `3px solid ${C.border}`, borderTop: `3px solid ${C.text}`, borderRadius: "50%", animation: "spin 0.9s linear infinite" }} />
          <p style={{ color: C.muted }}>Loading reports...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div style={{ background: C.text, padding: "16px 32px", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#faf5ee", letterSpacing: -0.5, fontFamily: "'Playfair Display', serif" }}>Good Answer</div>
        <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.2)", margin: "0 4px" }} />
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: 1, textTransform: "uppercase" }}>Reports Dashboard</div>
        <div style={{ marginLeft: "auto", fontSize: 13, color: "rgba(255,255,255,0.6)" }}>
          {filteredReports.length} report{filteredReports.length !== 1 ? "s" : ""}
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "44px 24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
          <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 0, fontFamily: "'Playfair Display', serif" }}>All Reports</h1>
          <Link to="/SubmitReport" style={{ background: C.text, border: "none", borderRadius: 8, padding: "12px 20px", color: "#faf5ee", fontWeight: 600, fontSize: 14, cursor: "pointer", textDecoration: "none", fontFamily: "'DM Sans', sans-serif" }}>
            + New Report
          </Link>
        </div>

        {/* Search Bar */}
        <div style={{ marginBottom: 24 }}>
          <input
            type="text"
            placeholder="Search by campaign, brand, or talent..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: "100%",
              background: C.card,
              border: `1px solid ${C.border}`,
              borderRadius: 8,
              padding: "11px 14px",
              color: C.text,
              fontSize: 14,
              fontFamily: "'DM Sans', sans-serif",
              boxSizing: "border-box",
            }}
          />
        </div>

        {/* Filters */}
        <div style={{ display: "flex", gap: 8, marginBottom: 28, flexWrap: "wrap" }}>
          {/* Status Filter */}
          {["all", "Processing", "Needs Review", "Sent"].map(status => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              style={{
                background: statusFilter === status ? C.text : C.card,
                border: `1px solid ${statusFilter === status ? C.text : C.border}`,
                borderRadius: 6,
                padding: "8px 14px",
                color: statusFilter === status ? "#faf5ee" : C.muted,
                fontSize: 13,
                cursor: "pointer",
                fontWeight: statusFilter === status ? 600 : 400,
                fontFamily: "'DM Sans', sans-serif",
              }}
            >
              {status === "all" ? "All Statuses" : status}
            </button>
          ))}

          {/* Brand Filter */}
          <select
            value={brandFilter}
            onChange={(e) => setBrandFilter(e.target.value)}
            style={{
              background: C.card,
              border: `1px solid ${brandFilter === "all" ? C.border : C.accent}`,
              borderRadius: 6,
              padding: "8px 12px",
              color: C.text,
              fontSize: 13,
              cursor: "pointer",
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: brandFilter === "all" ? 400 : 600,
            }}
          >
            <option value="all">All Brands</option>
            {uniqueBrands.map(brand => (
              <option key={brand} value={brand}>{brand}</option>
            ))}
          </select>

          {/* Talent Filter */}
          <select
            value={talentFilter}
            onChange={(e) => setTalentFilter(e.target.value)}
            style={{
              background: C.card,
              border: `1px solid ${talentFilter === "all" ? C.border : C.accent}`,
              borderRadius: 6,
              padding: "8px 12px",
              color: C.text,
              fontSize: 13,
              cursor: "pointer",
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: talentFilter === "all" ? 400 : 600,
            }}
          >
            <option value="all">All Talent</option>
            {uniqueTalents.map(talent => (
              <option key={talent} value={talent}>{talent}</option>
            ))}
          </select>

          {/* Performance Sort */}
          <select
            value={performanceSort}
            onChange={(e) => setPerformanceSort(e.target.value)}
            style={{
              background: C.card,
              border: `1px solid ${performanceSort === "none" ? C.border : C.accent}`,
              borderRadius: 6,
              padding: "8px 12px",
              color: C.text,
              fontSize: 13,
              cursor: "pointer",
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: performanceSort === "none" ? 400 : 600,
            }}
          >
            <option value="none">Sort by Performance</option>
            <option value="best">Best Performing</option>
            <option value="worst">Worst Performing</option>
          </select>
        </div>

        {/* Reports Table */}
        {filteredReports.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 20px", background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
            <p style={{ color: C.muted, fontSize: 15 }}>No reports found.</p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {filteredReports.map(report => (
              <div
                key={report.id}
                style={{
                  background: C.card,
                  border: `1px solid ${C.border}`,
                  borderRadius: 10,
                  padding: 20,
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr 1fr auto auto",
                  gap: 20,
                  alignItems: "center",
                }}
              >
                {/* Campaign */}
                <div>
                  <div style={{ fontSize: 11, color: C.muted, marginBottom: 4, textTransform: "uppercase", fontWeight: 500 }}>Campaign</div>
                  <Link to={`/Report?slug=${report.report_slug}`} style={{ fontSize: 15, fontWeight: 600, color: C.accent, textDecoration: "none" }}>
                    {report.campaign_name}
                  </Link>
                  <div style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>
                    {report.brand_name} · {report.creator_name}
                  </div>
                </div>

                {/* Xero & Placements */}
                <div>
                  {report.xero_quote_ref && (
                    <>
                      <div style={{ fontSize: 11, color: C.muted, marginBottom: 4, textTransform: "uppercase", fontWeight: 500 }}>Xero Ref</div>
                      <div style={{ fontSize: 14, fontWeight: 500 }}>{report.xero_quote_ref}</div>
                    </>
                  )}
                  {report.platforms && report.platforms.length > 0 && (
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 8 }}>
                      {report.platforms.slice(0, 2).map(p => (
                        <span key={p} style={{ background: "#ede9f8", color: C.accent, borderRadius: 4, padding: "2px 8px", fontSize: 11 }}>
                          {p}
                        </span>
                      ))}
                      {report.platforms.length > 2 && (
                        <span style={{ fontSize: 11, color: C.muted }}>+{report.platforms.length - 2}</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Status */}
                <div>
                  <div style={{ fontSize: 11, color: C.muted, marginBottom: 8, textTransform: "uppercase", fontWeight: 500 }}>Status</div>
                  <select
                    value={report.status}
                    onChange={e => updateStatus(report.id, e.target.value)}
                    style={{
                      background: C.card,
                      border: `1px solid ${C.border}`,
                      borderRadius: 6,
                      padding: "8px 10px",
                      color: statusColors[report.status] || C.text,
                      fontWeight: 600,
                      fontSize: 13,
                      cursor: "pointer",
                      fontFamily: "'DM Sans', sans-serif",
                    }}
                  >
                    <option value="Processing">Processing</option>
                    <option value="Needs Review">Needs Review</option>
                    <option value="Sent">Sent</option>
                  </select>
                </div>

                {/* Share Link */}
                <div style={{ textAlign: "right" }}>
                  <button
                    onClick={() => copyToClipboard(getShareLink(report.report_slug), report.id)}
                    style={{
                      background: C.accent,
                      border: "none",
                      borderRadius: 6,
                      padding: "8px 12px",
                      color: "#fff",
                      fontSize: 12,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontFamily: "'DM Sans', sans-serif",
                    }}
                  >
                    {copiedId === report.id ? "✓ Copied" : "Copy Link"}
                  </button>
                </div>

                {/* Actions */}
                <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                  <Link
                    to={`/SubmitReport?reportId=${report.id}`}
                    style={{
                      background: "transparent",
                      border: `1px solid ${C.border}`,
                      borderRadius: 6,
                      padding: "8px 12px",
                      color: C.text,
                      fontSize: 12,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontFamily: "'DM Sans', sans-serif",
                      textDecoration: "none",
                      display: "inline-block",
                    }}
                  >
                    Edit
                  </Link>
                  <button
                    onClick={() => handleDelete(report.id)}
                    style={{
                      background: "transparent",
                      border: `1px solid #f5c0c0`,
                      borderRadius: 6,
                      padding: "8px 12px",
                      color: "#b03030",
                      fontSize: 12,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontFamily: "'DM Sans', sans-serif",
                    }}
                  >
                    Delete
                  </button>
                  <a
                    href={`/Report?slug=${report.report_slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      background: "transparent",
                      border: `1px solid ${C.border}`,
                      borderRadius: 6,
                      padding: "8px 12px",
                      color: C.text,
                      fontSize: 12,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontFamily: "'DM Sans', sans-serif",
                      textDecoration: "none",
                      display: "inline-block",
                    }}
                  >
                    View →
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}


      </div>
    </div>
  );
}