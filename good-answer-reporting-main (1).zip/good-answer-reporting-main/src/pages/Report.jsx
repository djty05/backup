import { useState, useEffect } from "react";
import { getReport } from "../api/backendFunctions";

const C = {
  bg: "#faf5ee",
  text: "#3b1320",
  muted: "#8a6070",
  border: "#e8ddd0",
  accent: "#8883d1",
  card: "#fff",
  secondary: "#f3ede3",
};

export default function Report() {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const slug = new URLSearchParams(window.location.search).get("slug");
    if (!slug) {
      setError("No report slug provided");
      setLoading(false);
      return;
    }

    getReport({ slug })
      .then(res => {
        setReport(res.report);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message || "Failed to load report");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 48, height: 48, margin: "0 auto 20px", border: `3px solid ${C.border}`, borderTop: `3px solid ${C.text}`, borderRadius: "50%", animation: "spin 0.9s linear infinite" }} />
          <p style={{ color: C.muted }}>Loading report...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div style={{ textAlign: "center", color: C.text }}>
          <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 10, fontFamily: "'Playfair Display', serif" }}>Report not found</h1>
          <p style={{ color: C.muted }}>{error}</p>
        </div>
      </div>
    );
  }

  const formatMetricLabel = (key) => {
    return key.replace(/_/g, " ").split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div style={{ background: C.text, padding: "16px 32px", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#faf5ee", letterSpacing: -0.5, fontFamily: "'Playfair Display', serif" }}>Good Answer</div>
        <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.2)", margin: "0 4px" }} />
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: 1, textTransform: "uppercase" }}>Campaign Report</div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "44px 24px" }}>
        {/* Campaign Header */}
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 28, marginBottom: 32 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: 16 }}>
            <div>
              <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 4, fontFamily: "'Playfair Display', serif", color: C.text }}>
                {report.campaign_name}
              </h1>
              <p style={{ fontSize: 14, color: C.muted, marginBottom: 12 }}>
                {report.brand_name} · {report.creator_name}
              </p>
              {report.xero_quote_ref && (
                <p style={{ fontSize: 12, color: C.muted }}>Xero: {report.xero_quote_ref}</p>
              )}
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 12, color: C.muted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 4 }}>Status</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: report.status === "Approved" ? "#3a8a4a" : "#dd7d4f" }}>
                {report.status}
              </div>
            </div>
          </div>

          {/* Platforms & Placements */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {[...(report.platforms || []), ...(report.placement_types || [])].map(tag => (
              <span key={tag} style={{ background: "#ede9f8", border: `1px solid #d0cdf0`, color: C.accent, borderRadius: 4, padding: "3px 10px", fontSize: 11, fontFamily: "'DM Sans', sans-serif" }}>
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Metrics by Deliverable */}
        {(() => {
          let assets = [];
          if (report?.asset_metrics_json) {
            try { assets = JSON.parse(report.asset_metrics_json); } catch (e) {}
          }
          if (assets.length === 0 && report?.asset_metrics?.length > 0) {
            assets = report.asset_metrics;
          }
          if (assets.length === 0) return null;
          return (
            <div style={{ marginBottom: 32 }}>
              <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 16, fontFamily: "'Playfair Display', serif" }}>Performance by Deliverable</h2>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {assets.map((asset, idx) => {
                  const metrics = Object.entries(asset.metrics || {})
                    .filter(([_, val]) => val !== null && val !== undefined)
                    .map(([key, val]) => {
                      const isRate = key.includes('rate');
                      const displayVal = typeof val === 'number' ? (val % 1 !== 0 ? val.toFixed(2) : val.toLocaleString()) : '—';
                      return { key, label: formatMetricLabel(key), displayVal, isRate };
                    });
                  const assetLabel = asset.label || (asset.platform && asset.type ? `${asset.platform} / ${asset.type}` : asset.type || `Deliverable ${idx + 1}`);
                  return (
                    <div key={idx} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 20 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: C.muted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 14 }}>
                        {assetLabel}
                      </div>
                      {metrics.length > 0 ? (
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: 10 }}>
                          {metrics.map(metric => (
                            <div key={metric.key} style={{ background: C.secondary, borderRadius: 8, padding: "12px 10px", textAlign: "center" }}>
                              <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, fontWeight: 500 }}>{metric.label}</div>
                              <div style={{ fontSize: 20, fontWeight: 700, color: C.text }}>
                                {metric.displayVal}{metric.isRate ? '%' : ''}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div style={{ fontSize: 13, color: C.muted }}>No metrics extracted for this deliverable</div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })()}

        {/* Always show top-level metrics summary */}
        {(() => {
          const metricKeys = ["total_views", "total_reach", "likes", "comments_count", "shares", "saves", "link_clicks", "engagement_rate"];
          const topMetrics = metricKeys
            .filter(k => report[k] !== null && report[k] !== undefined)
            .map(k => ({ label: formatMetricLabel(k), value: report[k] }));

          if (topMetrics.length > 0) {
            return (
              <div style={{ marginBottom: 32 }}>
                <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 16, fontFamily: "'Playfair Display', serif" }}>
                  {(() => {
                    // Check if we have asset metrics
                    let assets = report?.asset_metrics || [];
                    if (assets.length === 0 && report?.asset_metrics_json) {
                      try {
                        assets = JSON.parse(report.asset_metrics_json);
                      } catch (e) {}
                    }
                    return assets.length > 0 ? "Summary Metrics" : "Campaign Metrics";
                  })()}
                </h2>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
                  {topMetrics.map(metric => (
                    <div key={metric.label} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16, textAlign: "center" }}>
                      <div style={{ fontSize: 12, color: C.muted, marginBottom: 6, fontWeight: 500 }}>{metric.label}</div>
                      <div style={{ fontSize: 24, fontWeight: 700, color: C.text }}>
                        {typeof metric.value === "number" ? (
                          metric.value.toString().includes(".") ? metric.value.toFixed(2) : metric.value
                        ) : "—"}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          }
          return null;
        })()}



        {/* Content Link */}
        {report.content_link && (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16, marginBottom: 20 }}>
            <p style={{ fontSize: 12, color: C.muted, marginBottom: 8, fontWeight: 500 }}>Content</p>
            <a href={report.content_link} target="_blank" rel="noopener noreferrer"
              style={{ color: C.accent, textDecoration: "none", fontSize: 14, fontWeight: 500, display: "flex", alignItems: "center", gap: 4 }}>
              {report.content_link} →
            </a>
          </div>
        )}

        {/* Campaign Folder Link */}
        {report.google_drive_link && (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16, marginBottom: 32 }}>
            <p style={{ fontSize: 12, color: C.muted, marginBottom: 8, fontWeight: 500 }}>Supporting data</p>
            <a href={report.google_drive_link} target="_blank" rel="noopener noreferrer"
              style={{ color: C.accent, textDecoration: "none", fontSize: 14, fontWeight: 500, display: "flex", alignItems: "center", gap: 4 }}>
              View Screen shots / Foam report →
            </a>
          </div>
        )}

        {/* AI Analysis */}
        {(report.vibe_analysis || report.extension_pitch) && (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 24 }}>
            {report.vibe_analysis && (
              <div style={{ marginBottom: 20 }}>
                <h3 style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 8, fontFamily: "'Playfair Display', serif" }}>Vibe Analysis</h3>
                <p style={{ fontSize: 14, color: C.muted, lineHeight: 1.6 }}>{report.vibe_analysis}</p>
              </div>
            )}

            {report.extension_pitch && (
              <div>
                <h3 style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 8, fontFamily: "'Playfair Display', serif" }}>Extension Pitch</h3>
                <p style={{ fontSize: 14, color: C.muted, lineHeight: 1.6 }}>{report.extension_pitch}</p>
              </div>
            )}
          </div>
        )}

        {/* Top Sentiments */}
        {report.top_sentiments && report.top_sentiments.length > 0 && (
          <div style={{ marginTop: 24 }}>
            <p style={{ fontSize: 12, color: C.muted, marginBottom: 10, fontWeight: 500 }}>Audience Sentiments</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {report.top_sentiments.map(sentiment => (
                <span key={sentiment} style={{ background: "#ede9f8", border: `1px solid #d0cdf0`, color: C.accent, borderRadius: 6, padding: "4px 12px", fontSize: 12 }}>
                  {sentiment}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}