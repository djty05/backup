async function callFunction(name, payload) {
  const res = await fetch(`/functions/${name}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error || err?.message || `Request failed with status ${res.status}`);
  }
  return res.json();
}

export const extractReportData = (payload) => callFunction('extractReportData', payload);
export const uploadToGoogleDrive = (payload) => callFunction('uploadToGoogleDrive', payload);
export const createReport = (payload) => callFunction('createReport', payload);
export const getReport = (payload) => callFunction('getReport', payload);
export const parseFoamReport = (payload) => callFunction('parseFoamReport', payload);
export const listReports = (payload) => callFunction('listReports', payload);
export const updateReportStatus = (payload) => callFunction('updateReportStatus', payload);
export const deleteReport = (payload) => callFunction('deleteReport', payload);
export const updateReport = (payload) => callFunction('updateReport', payload);