import { createClient } from '@base44/sdk';

export const base44 = createClient({
  appId: "69b9e58a06c22782dff35fc4",
  requiresAuth: false,
});

export async function requireAuth() {
  const isAuth = await base44.auth.isAuthenticated();
  if (!isAuth) {
    throw new Error('Workspace access required');
  }
}