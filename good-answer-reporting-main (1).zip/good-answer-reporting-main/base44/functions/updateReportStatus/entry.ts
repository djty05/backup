import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { reportId, status } = await req.json();

    if (!reportId || !status) {
      return Response.json({ error: 'Missing reportId or status' }, { status: 400 });
    }

    await base44.asServiceRole.entities.CampaignReport.update(reportId, { status });
    
    // If status is set to Processing and report has a google_drive_link, re-trigger extraction
    if (status === 'Processing') {
      const report = await base44.asServiceRole.entities.CampaignReport.get(reportId);
      if (report?.google_drive_link) {
        // Re-trigger extraction in background
        base44.asServiceRole.functions.invoke('extractReportData', {
          reportId,
          driveFolderLink: report.google_drive_link,
          deliverables: [], // Will be reconstructed from report platforms/placements
          postUrl: report.content_link || '',
          platforms: report.platforms || []
        }).catch(() => {});
      }
    }
    
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});