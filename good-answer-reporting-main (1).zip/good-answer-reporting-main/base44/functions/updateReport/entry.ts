import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { reportId, data } = await req.json();

    if (!reportId) {
      return Response.json({ error: 'No report ID provided' }, { status: 400 });
    }

    await base44.asServiceRole.entities.CampaignReport.update(reportId, data);
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});